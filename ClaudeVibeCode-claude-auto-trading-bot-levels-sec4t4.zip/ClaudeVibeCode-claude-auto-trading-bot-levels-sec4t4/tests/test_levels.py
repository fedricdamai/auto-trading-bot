import numpy as np
import pandas as pd
import pytest

from bot.levels import find_support_resistance, _find_swing_points, _cluster_levels, _count_touches


def _make_candles(prices: list[float]) -> pd.DataFrame:
    """Create a simple DataFrame where open=close=price, high=price+1, low=price-1."""
    return pd.DataFrame({
        "open": prices,
        "high": [p + 1 for p in prices],
        "low": [p - 1 for p in prices],
        "close": prices,
        "volume": [100] * len(prices),
    })


class TestFindSwingPoints:
    def test_detects_local_max(self):
        highs = np.array([10, 12, 15, 12, 10, 8, 6, 8, 10, 12, 14])
        lows = np.array([9, 11, 14, 11, 9, 7, 5, 7, 9, 11, 13])
        points = _find_swing_points(highs, lows, window=2)
        assert 15 in points

    def test_detects_local_min(self):
        highs = np.array([10, 8, 6, 8, 10, 12, 14, 12, 10, 8, 6])
        lows = np.array([9, 7, 5, 7, 9, 11, 13, 11, 9, 7, 5])
        points = _find_swing_points(highs, lows, window=2)
        assert 5 in points


class TestClusterLevels:
    def test_groups_nearby_prices(self):
        prices = [100.0, 100.3, 100.5, 110.0, 110.2]
        result = _cluster_levels(prices, tolerance=0.01)
        assert len(result) == 2

    def test_empty_input(self):
        assert _cluster_levels([], tolerance=0.01) == []

    def test_single_price(self):
        result = _cluster_levels([50.0], tolerance=0.01)
        assert result == [50.0]


class TestCountTouches:
    def test_counts_candles_touching_level(self):
        highs = np.array([105, 102, 108, 101, 103])
        lows = np.array([95, 98, 96, 99, 97])
        touches = _count_touches(100.0, highs, lows, tolerance=0.02)
        assert touches == 5

    def test_no_touches_when_far(self):
        highs = np.array([200, 210, 205])
        lows = np.array([190, 195, 198])
        touches = _count_touches(100.0, highs, lows, tolerance=0.01)
        assert touches == 0


class TestFindSupportResistance:
    def test_returns_support_and_resistance(self):
        prices = (
            [100] * 10
            + [i for i in range(100, 120)]
            + [120] * 10
            + [i for i in range(120, 100, -1)]
            + [100] * 10
            + [i for i in range(100, 115)]
            + [115] * 10
            + [i for i in range(115, 105, -1)]
            + [105] * 10
        )
        df = _make_candles(prices)
        result = find_support_resistance(df, tolerance_pct=1.0, min_touches=2)
        assert "support" in result
        assert "resistance" in result
        assert "current_price" in result
        assert result["current_price"] == prices[-1]

    def test_current_price_is_last_close(self):
        prices = list(range(50, 150))
        df = _make_candles(prices)
        result = find_support_resistance(df, tolerance_pct=0.5, min_touches=1)
        assert result["current_price"] == 149
