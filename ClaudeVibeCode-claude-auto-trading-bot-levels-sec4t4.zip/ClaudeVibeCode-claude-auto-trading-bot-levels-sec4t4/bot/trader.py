import logging
import time
from dataclasses import dataclass

from bot.config import Config
from bot.levels import find_support_resistance
from bot.telegram_notifier import TelegramNotifier

logger = logging.getLogger(__name__)


@dataclass
class ActiveOrder:
    level: float
    level_type: str  # "support" or "resistance"
    order: dict
    stop_loss: float
    take_profit: float


class Trader:
    """Core trading logic: detect levels, place buys at support & resistance."""

    def __init__(self, config: Config, exchange, notifier: TelegramNotifier | None = None):
        self.config = config
        self.exchange = exchange
        self.notifier = notifier
        self.active_orders: list[ActiveOrder] = []
        self.traded_levels: set[float] = set()

    def run_once(self) -> dict:
        """Run a single iteration: detect levels, check proximity, place orders."""
        df = self.exchange.fetch_ohlcv()
        levels = find_support_resistance(
            df,
            tolerance_pct=self.config.level_tolerance_pct,
            min_touches=self.config.min_touches,
        )

        current_price = levels["current_price"]
        support_levels = levels["support"]
        resistance_levels = levels["resistance"]

        logger.info(
            f"Price: {current_price:.2f} | "
            f"Support: {support_levels[:5]} | "
            f"Resistance: {resistance_levels[:5]}"
        )

        if self.notifier:
            self.notifier.notify_levels(current_price, support_levels, resistance_levels)

        orders_placed = []
        entry_tolerance = self.config.entry_tolerance_pct / 100.0

        for level in support_levels:
            if level in self.traded_levels:
                continue
            distance_pct = abs(current_price - level) / current_price
            if distance_pct <= entry_tolerance:
                order = self._place_buy_at_level(level, "support", current_price)
                if order:
                    orders_placed.append(order)

        for level in resistance_levels:
            if level in self.traded_levels:
                continue
            distance_pct = abs(current_price - level) / current_price
            if distance_pct <= entry_tolerance:
                order = self._place_buy_at_level(level, "resistance", current_price)
                if order:
                    orders_placed.append(order)

        self._check_exits(current_price)

        return {
            "current_price": current_price,
            "support_levels": support_levels[:5],
            "resistance_levels": resistance_levels[:5],
            "orders_placed": len(orders_placed),
            "active_orders": len(self.active_orders),
        }

    def _place_buy_at_level(self, level: float, level_type: str, current_price: float) -> ActiveOrder | None:
        try:
            order = self.exchange.place_market_buy(self.config.order_size)

            entry_price = current_price
            stop_loss = entry_price * (1 - self.config.stop_loss_pct / 100)
            take_profit = entry_price * (1 + self.config.take_profit_pct / 100)

            active = ActiveOrder(
                level=level,
                level_type=level_type,
                order=order,
                stop_loss=stop_loss,
                take_profit=take_profit,
            )
            self.active_orders.append(active)
            self.traded_levels.add(level)

            logger.info(
                f"BUY at {level_type} {level:.2f} | "
                f"Entry: {entry_price:.2f} | "
                f"SL: {stop_loss:.2f} | TP: {take_profit:.2f}"
            )

            if self.notifier:
                self.notifier.notify_buy(
                    level, level_type, entry_price,
                    order.get("amount", 0), stop_loss, take_profit,
                )
            return active

        except Exception as e:
            logger.error(f"Failed to place order at {level_type} {level:.2f}: {e}")
            if self.notifier:
                self.notifier.notify_error(str(e))
            return None

    def _check_exits(self, current_price: float):
        remaining = []
        for active in self.active_orders:
            if current_price <= active.stop_loss:
                logger.info(
                    f"STOP LOSS hit for {active.level_type} {active.level:.2f} | "
                    f"Price: {current_price:.2f}"
                )
                if self.notifier:
                    self.notifier.notify_exit("stop_loss", active.level, active.level_type, current_price)
                self.traded_levels.discard(active.level)
            elif current_price >= active.take_profit:
                logger.info(
                    f"TAKE PROFIT hit for {active.level_type} {active.level:.2f} | "
                    f"Price: {current_price:.2f}"
                )
                if self.notifier:
                    self.notifier.notify_exit("take_profit", active.level, active.level_type, current_price)
                self.traded_levels.discard(active.level)
            else:
                remaining.append(active)
        self.active_orders = remaining

    def run_loop(self):
        mode = "PAPER" if self.config.paper_trade else "LIVE"
        backend = self.config.exchange_backend.upper()
        symbol = self.config.hl_symbol if self.config.exchange_backend == "hyperliquid" else self.config.symbol

        logger.info(f"Starting bot [{mode}] on {backend} — {symbol} ({self.config.timeframe})")

        if self.notifier:
            self.notifier.notify_startup(symbol, self.config.timeframe, self.config.paper_trade)

        while True:
            try:
                summary = self.run_once()
                logger.info(f"Cycle complete: {summary}")
            except Exception as e:
                logger.error(f"Error in trading cycle: {e}")
                if self.notifier:
                    self.notifier.notify_error(str(e))
            time.sleep(self.config.check_interval)
