import numpy as np
import pandas as pd


def find_support_resistance(df: pd.DataFrame, tolerance_pct: float, min_touches: int) -> dict:
    """Detect support and resistance levels from OHLCV candle data.

    Uses a local-extrema approach: finds swing highs/lows, then clusters
    nearby price points into levels and ranks them by touch count.

    Args:
        df: DataFrame with columns [open, high, low, close, volume].
        tolerance_pct: Max percentage distance to group prices into one level.
        min_touches: Minimum touches required to confirm a level.

    Returns:
        {"support": [...], "resistance": [...]} each sorted closest-to-price first.
    """
    highs = df["high"].values
    lows = df["low"].values
    close = df["close"].values
    current_price = close[-1]

    swing_points = _find_swing_points(highs, lows, window=5)

    tolerance = tolerance_pct / 100.0
    levels = _cluster_levels(swing_points, tolerance)

    confirmed = [
        lvl for lvl in levels
        if _count_touches(lvl, highs, lows, tolerance) >= min_touches
    ]

    support = sorted(
        [l for l in confirmed if l < current_price],
        key=lambda x: abs(current_price - x),
    )
    resistance = sorted(
        [l for l in confirmed if l >= current_price],
        key=lambda x: abs(current_price - x),
    )

    return {"support": support, "resistance": resistance, "current_price": current_price}


def _find_swing_points(highs: np.ndarray, lows: np.ndarray, window: int) -> list[float]:
    """Identify local maxima in highs and local minima in lows."""
    points = []
    n = len(highs)

    for i in range(window, n - window):
        if highs[i] == max(highs[i - window : i + window + 1]):
            points.append(highs[i])
        if lows[i] == min(lows[i - window : i + window + 1]):
            points.append(lows[i])

    return points


def _cluster_levels(prices: list[float], tolerance: float) -> list[float]:
    """Group nearby price points into single levels using their mean."""
    if not prices:
        return []

    sorted_prices = sorted(prices)
    clusters: list[list[float]] = [[sorted_prices[0]]]

    for price in sorted_prices[1:]:
        cluster_mean = np.mean(clusters[-1])
        if abs(price - cluster_mean) / cluster_mean <= tolerance:
            clusters[-1].append(price)
        else:
            clusters.append([price])

    return [round(float(np.mean(c)), 2) for c in clusters]


def _count_touches(level: float, highs: np.ndarray, lows: np.ndarray, tolerance: float) -> int:
    """Count how many candles touch a price level within tolerance."""
    band_low = level * (1 - tolerance)
    band_high = level * (1 + tolerance)

    touches = 0
    for h, l in zip(highs, lows):
        if l <= band_high and h >= band_low:
            touches += 1
    return touches
