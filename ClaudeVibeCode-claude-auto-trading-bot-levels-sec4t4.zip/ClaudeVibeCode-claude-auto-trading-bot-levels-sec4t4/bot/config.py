import os
from dataclasses import dataclass
from dotenv import load_dotenv

load_dotenv()


@dataclass
class Config:
    # Exchange backend: "ccxt" or "hyperliquid"
    exchange_backend: str = os.getenv("EXCHANGE_BACKEND", "hyperliquid")

    # ccxt settings (used when EXCHANGE_BACKEND=ccxt)
    exchange_id: str = os.getenv("EXCHANGE_ID", "binance")
    api_key: str = os.getenv("API_KEY", "")
    api_secret: str = os.getenv("API_SECRET", "")
    symbol: str = os.getenv("SYMBOL", "BTC/USDT")

    # Hyperliquid settings (used when EXCHANGE_BACKEND=hyperliquid)
    hl_wallet_address: str = os.getenv("HL_WALLET_ADDRESS", "")
    hl_private_key: str = os.getenv("HL_PRIVATE_KEY", "")
    hl_symbol: str = os.getenv("HL_SYMBOL", "BTC")
    hl_leverage: int = int(os.getenv("HL_LEVERAGE", "1"))
    hl_mainnet: bool = os.getenv("HL_MAINNET", "false").lower() == "true"

    # Shared trading settings
    timeframe: str = os.getenv("TIMEFRAME", "1h")
    lookback_candles: int = int(os.getenv("LOOKBACK_CANDLES", "200"))
    min_touches: int = int(os.getenv("MIN_TOUCHES", "2"))
    level_tolerance_pct: float = float(os.getenv("LEVEL_TOLERANCE_PCT", "0.5"))
    order_size: float = float(os.getenv("ORDER_SIZE", "50"))
    entry_tolerance_pct: float = float(os.getenv("ENTRY_TOLERANCE_PCT", "0.3"))
    stop_loss_pct: float = float(os.getenv("STOP_LOSS_PCT", "2.0"))
    take_profit_pct: float = float(os.getenv("TAKE_PROFIT_PCT", "4.0"))
    check_interval: int = int(os.getenv("CHECK_INTERVAL", "60"))
    paper_trade: bool = os.getenv("PAPER_TRADE", "true").lower() == "true"
    log_level: str = os.getenv("LOG_LEVEL", "INFO")

    # Telegram notifications (optional)
    tg_bot_token: str = os.getenv("TG_BOT_TOKEN", "")
    tg_chat_id: str = os.getenv("TG_CHAT_ID", "")

    @property
    def telegram_enabled(self) -> bool:
        return bool(self.tg_bot_token and self.tg_chat_id)
